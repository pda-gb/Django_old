#!/bin/bash

python3.7 manage.py runserver
